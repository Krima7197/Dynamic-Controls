//
//  controls.swift
//  dynamicControls
//
//  Created by TOPS on 8/27/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class controls: NSObject
{
    func createbtn(frm:CGRect,color:UIColor,img:UIImage) -> UIButton
    {
        let btn=UIButton(type: .custom)
        btn.frame=frm
        btn.backgroundColor=color
        btn.setImage(img, for: .normal)
        return btn
    }
    func createTextfield(frm:CGRect,place:String,bcolor:UIColor,bwidth:Int) -> UITextField
    {
        let text=UITextField(frame: frm)
        let border = CALayer()
        let width = CGFloat(2.0)
        border.borderColor = bcolor.cgColor
        border.frame=CGRect(x: 0, y: text.frame.size.height-width, width: text.frame.size.width, height: text.frame.size.height)
        let img = UIImageView(frame:CGRect(x: 0, y: 0, width: 30, height: 30))
        img.image=UIImage(named: "1.png")
        text.leftViewMode = .always
        text.leftView = img
        border.borderWidth=width
        text.layer.addSublayer(border)
        text.layer.masksToBounds=true
        text.placeholder=place
        text.clipsToBounds=true
        text.layer.cornerRadius=10
        text.layer.borderColor=bcolor.cgColor
        text.layer.borderWidth=CGFloat(bwidth)
        return text
    }
}
