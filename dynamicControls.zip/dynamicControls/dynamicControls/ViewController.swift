//
//  ViewController.swift
//  dynamicControls
//
//  Created by TOPS on 8/27/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        //btncreate()
        //Single button
        let cm=controls()
        let txt=cm.createTextfield(frm: CGRect(x:10,y:50,width:200,height:30), place: "Enter user name : ", bcolor: UIColor.black, bwidth: 2)
        txt.addTarget(self, action: #selector(self.edit), for: .editingChanged)
        self.view.addSubview(txt)
        /*let btn=cm.createbtn(frm: CGRect(x:20,y:20,width:100,height:100), color: UIColor.blue, img: UIImage(named: "1.png")!)
        btn.addTarget(self, action: #selector(self.test), for: .touchUpInside)
        self.view.addSubview(btn)*/
        // Do any additional setup after loading the view, typically from a nib.
        //Multiple buttons
        /*let cm=controls()
        let src=UIScrollView(frame: self.view.bounds)
        var y=20
        for i in 0...10
        {   let btn=cm.createbtn(frm: CGRect(x:20,y:y,width:100,height:100), color: UIColor.brown,img: UIImage(named: "1.png")!)
            btn.tag=i
            btn.addTarget(self, action: #selector(self.test), for: .touchUpInside)
            src.addSubview(btn)
            y=y+120
        }
        src.contentSize=CGSize(width: self.view.frame.size.width, height: CGFloat(y))
         
        self.view.addSubview(src)*/
    }
    func edit(sender:UITextField)
    {
        print(sender.text!)
    }
    /*func btncreate()
    {   let btn=UIButton(type: .custom)
        btn.frame=CGRect(x: 20, y: 50, width: 100, height: 100)
        btn.setImage(UIImage(named:"1.jpeg"), for: .normal)
        btn.addTarget(self, action: #selector(self.test), for: .touchUpInside)
        self.view.addSubview(btn)
    }*/
    func test(sender:UIButton) {
        print(sender.tag)
        print("Clicked")
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

